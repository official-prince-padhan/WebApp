<?php

$data['PageName']='Device Confirmation';
$data['PageFile']='device_confirmations';
$data['noheader']=1;

include "header.php"; 

?>



